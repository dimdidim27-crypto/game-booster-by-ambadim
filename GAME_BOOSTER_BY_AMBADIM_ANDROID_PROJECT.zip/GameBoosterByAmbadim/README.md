# GAME BOOSTER by AMBADIM

Project Android native (Java) sederhana, minSdk 23.

## Membuat APK
1. Ekstrak ZIP ini.
2. Buka folder `GameBoosterByAmbadim` di Android Studio.
3. Tunggu Gradle Sync selesai (butuh internet pertama kali untuk mengunduh Android Gradle Plugin).
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Fitur yang benar-benar bekerja
- Sakelar profil booster ON/OFF di dalam aplikasi.
- Volume media perangkat.
- Kecerahan layar saat aplikasi terbuka.
- Daftar aplikasi yang bisa diluncurkan.
- Tombol menuju pengaturan Battery Saver Android.
- Pilihan FPS/grafik dan slider sensitivitas sebagai preset/rekomendasi, bukan pengubah paksa sistem.

## Batasan Android
Aplikasi biasa tidak dapat memaksa FPS game lain, mengubah kualitas grafik game lain, mengubah sensitivitas sentuh global, atau mengubah mode stabil sistem tanpa dukungan sistem/OEM, hak istimewa khusus, atau pengaturan di game. Launcher ini tidak melakukan overclock/root dan tidak menjanjikan peningkatan FPS.
