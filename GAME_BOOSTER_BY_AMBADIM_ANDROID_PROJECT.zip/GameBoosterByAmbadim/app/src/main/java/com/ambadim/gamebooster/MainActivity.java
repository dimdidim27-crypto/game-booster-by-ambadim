package com.ambadim.gamebooster;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.media.AudioManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    int red = Color.rgb(255,48,48), bg = Color.rgb(9,9,9), panel = Color.rgb(24,24,27);
    LinearLayout page;
    boolean boosterOn = false;
    AudioManager audio;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        audio = (AudioManager)getSystemService(AUDIO_SERVICE);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        ScrollView scroll = new ScrollView(this);
        page = new LinearLayout(this); page.setOrientation(1); page.setPadding(18,18,18,28);
        page.setBackgroundColor(bg); scroll.addView(page); setContentView(scroll);
        header();
        statusCard();
        section("PENGATURAN PERFORMA");
        choiceCard("Target FPS", "Pilih target tampilan (tidak memaksa FPS game)", new String[]{"30 FPS","60 FPS","90 FPS","120 FPS"}, "60 FPS");
        choiceCard("Grafik", "Preset rekomendasi untuk pengaturan di dalam game", new String[]{"Rendah","Sedang","Tinggi","Ultra"}, "Sedang");
        switchCard("Mode hemat baterai", "Aktifkan profil hemat daya di aplikasi", false, null);
        switchCard("Mode stabil", "Profil rekomendasi untuk sesi bermain stabil", true, null);
        section("KONTROL PERANGKAT");
        sliderCard("Sensitivitas sentuh", "Pengingat nilai sensitivitas (atur juga di game)", 1, 100, 50, "%");
        sliderCard("Volume media", "Mengubah volume media perangkat", 0, audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
            audio.getStreamVolume(AudioManager.STREAM_MUSIC), "");
        sliderCard("Kecerahan layar", "Mengubah kecerahan selama aplikasi ini terbuka", 5, 100, 65, "%");
        Button battery = button("BUKA PENGATURAN HEMAT BATERAI");
        battery.setOnClickListener(v -> { try { startActivity(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)); } catch(Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }});
        page.addView(battery);
        section("GAME DI PERANGKAT");
        Button refresh = button("MUAT ULANG DAFTAR GAME"); page.addView(refresh);
        LinearLayout games = new LinearLayout(this); games.setOrientation(1); page.addView(games);
        refresh.setOnClickListener(v -> loadGames(games)); loadGames(games);
        TextView note = text("Catatan: Android membatasi aplikasi pihak ketiga. FPS, grafik, sensitivitas global, dan mode stabil tidak bisa dipaksa oleh launcher biasa. Gunakan pengaturan di dalam game/perangkat untuk perubahan sistem.", 12, 0xFFAAAAAA);
        note.setPadding(4,18,4,8); page.addView(note);
    }

    void header() {
        TextView brand = text("AMBADIM  /  GAMING UTILITY", 11, red); brand.setLetterSpacing(.16f); page.addView(brand);
        TextView title = text("GAME BOOSTER", 30, Color.WHITE); title.setTypeface(null, Typeface.BOLD); title.setPadding(0,8,0,2); page.addView(title);
        TextView sub = text("KENDALIKAN SESI BERMAINMU", 11, 0xFFAAAAAA); page.addView(sub);
    }
    void statusCard() {
        LinearLayout c = card(); c.setOrientation(1);
        TextView t = text("BOOSTER UTAMA", 12, 0xFFBBBBBB); c.addView(t);
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setOrientation(0);
        TextView state = text("●  NONAKTIF", 19, red); state.setTypeface(null, Typeface.BOLD); row.addView(state, new LinearLayout.LayoutParams(0,-2,1));
        Switch sw = new Switch(this); sw.setButtonTintList(null); sw.setChecked(false);
        sw.setOnCheckedChangeListener((v,on)->{ boosterOn=on; state.setText(on?"●  BOOSTER AKTIF":"●  NONAKTIF"); state.setTextColor(on?0xFF55DD88:red); });
        row.addView(sw); c.addView(row);
        c.addView(text("Sakelar ini mengaktifkan profil di aplikasi, bukan membuka akses sistem tersembunyi.", 12, 0xFF999999));
        page.addView(c);
    }
    void section(String s) { TextView t=text(s,12,red); t.setTypeface(null,Typeface.BOLD); t.setLetterSpacing(.12f); t.setPadding(2,22,2,9); page.addView(t); }
    LinearLayout card() {
        LinearLayout c=new LinearLayout(this); c.setOrientation(1); c.setPadding(15,13,15,13);
        GradientDrawable d=new GradientDrawable(); d.setColor(panel); d.setCornerRadius(18); d.setStroke(1,0xFF38383D); c.setBackground(d);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,5,0,7); page.addView(c,p); return c;
    }
    TextView text(String s,int size,int color) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t; }
    void choiceCard(String title,String desc,String[] opts,String initial) {
        LinearLayout c=card(); c.addView(text(title,16,Color.WHITE)); c.addView(text(desc,11,0xFF999999));
        Spinner sp=new Spinner(this); ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,opts); sp.setAdapter(a);
        sp.setSelection(Arrays.asList(opts).indexOf(initial)); c.addView(sp);
    }
    void switchCard(String title,String desc,boolean initial, CompoundButton.OnCheckedChangeListener listener) {
        LinearLayout c=card(); LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout labels=new LinearLayout(this); labels.setOrientation(1);
        labels.addView(text(title,15,Color.WHITE)); labels.addView(text(desc,11,0xFF999999));
        r.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        Switch sw=new Switch(this); sw.setChecked(initial); if(listener!=null) sw.setOnCheckedChangeListener(listener); r.addView(sw); c.addView(r);
    }
    void sliderCard(String title,String desc,int min,int max,int value,String suffix) {
        LinearLayout c=card(); c.addView(text(title,15,Color.WHITE)); c.addView(text(desc,11,0xFF999999));
        TextView val=text("",13,red); val.setTypeface(null,Typeface.BOLD); c.addView(val);
        SeekBar bar=new SeekBar(this); bar.setMax(Math.max(1,max-min)); bar.setProgress(Math.max(0,Math.min(max-min,value-min))); c.addView(bar);
        Runnable update=()->val.setText((min+bar.getProgress())+suffix); update.run();
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean u){ update.run();
                int n=min+p;
                if(title.equals("Volume media")) audio.setStreamVolume(AudioManager.STREAM_MUSIC,n,0);
                if(title.equals("Kecerahan layar")) { WindowManager.LayoutParams lp=getWindow().getAttributes(); lp.screenBrightness=Math.max(.05f,Math.min(1f,n/100f)); getWindow().setAttributes(lp); }
            }
            public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
        });
    }
    Button button(String s) {
        Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(12);
        GradientDrawable d=new GradientDrawable(); d.setColor(red); d.setCornerRadius(14); b.setBackground(d);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,10,0,8); b.setLayoutParams(p); return b;
    }
    void loadGames(LinearLayout list) {
        list.removeAllViews();
        PackageManager pm=getPackageManager();
        Intent query=new Intent(Intent.ACTION_MAIN,null); query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps=pm.queryIntentActivities(query,0);
        Collections.sort(apps,(a,b)->String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));
        int count=0;
        for(ResolveInfo ri:apps) {
            String pkg=ri.activityInfo.packageName;
            if(pkg.equals(getPackageName())) continue;
            String name=String.valueOf(ri.loadLabel(pm));
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(10,8,10,8);
            TextView label=text(name,14,Color.WHITE); row.addView(label,new LinearLayout.LayoutParams(0,-2,1));
            Button launch=new Button(this); launch.setText("MAIN"); launch.setTextSize(10); launch.setTextColor(red);
            launch.setOnClickListener(v->{ Intent i=pm.getLaunchIntentForPackage(pkg); if(i!=null) startActivity(i); });
            row.addView(launch); list.addView(row); count++;
            if(count>=80) break;
        }
        if(count==0) list.addView(text("Tidak ada aplikasi yang dapat diluncurkan.",13,0xFFAAAAAA));
    }
}